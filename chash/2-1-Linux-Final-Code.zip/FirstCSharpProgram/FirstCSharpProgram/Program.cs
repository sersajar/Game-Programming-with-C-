﻿using System;

namespace FirstCSharpProgram
{
	/// <summary>
	/// A class that prints a message
	/// </summary>
	class MainClass
	{
		/// <summary>
		/// Main method to print message
		/// </summary>
		/// <param name="args">command-line args</param>
		public static void Main (string[] args)
		{
			// print a message
			Console.WriteLine("Hi, smart n00b");

			Console.WriteLine();
		}
	}
}
