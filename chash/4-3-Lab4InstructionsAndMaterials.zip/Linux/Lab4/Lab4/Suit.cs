﻿using System;

namespace Lab4
{
	/// <summary>
	/// An enumeration for card suits
	/// </summary>
	public enum Suit
	{
		Clubs,
		Diamonds,
		Hearts,
		Spades
	}
}