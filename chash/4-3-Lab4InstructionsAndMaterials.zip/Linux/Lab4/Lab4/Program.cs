﻿using System;

namespace Lab4
{
	/// <summary>
	/// Implements Lab 4 functionality
	/// </summary>
	class MainClass
	{
		/// <summary>
		/// Implements Lab 4 functionality
		/// </summary>
		/// <param name="args">command-line args</param>
		public static void Main (string[] args)
		{
			// create a new deck and print the contents of the deck

			// shuffle the deck and print the contents of the deck

			// take the top card from the deck and print the card rank and suit

			// take the top card from the deck and print the card rank and suit

		}
	}
}